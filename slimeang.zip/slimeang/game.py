from pygame import *
from random import randint

init()
w = 1600
h = 800
info = display.Info()
fullscreen_size = (info.current_w, info.current_h)
is_fullscreen = False
window = display.set_mode((w, h), RESIZABLE)
clock = time.Clock()
start = 10
Fps = 60
loose_bg = transform.scale(image.load("loose_bg.jpg"), (w, h))
mixer.init()
mixer.music.load("music.ogg")
mixer.music.set_volume(0.35)
mixer.music.play()
death = mixer.Sound("death.ogg")
regenerate = mixer.Sound("life.ogg")
loose = mixer.Sound("loose.ogg")
quack = mixer.Sound("quack.ogg")
virtual_surface = Surface((w, h))
current_size = window.get_size()
last_size = current_size
up = False
down = False
left = False
right = False
leftb = False
rightb = False

catan = [image.load("cat1.png")]
catan2 = [image.load("cat2.png")]
walkright = [image.load("right.png"),image.load("right.png"),image.load("right.png"),image.load("right.png"),image.load("right.png"),image.load("right.png")]
walkleft = [image.load("left.png"),image.load("left.png"),image.load("left.png"),image.load("left.png"),image.load("left.png"),image.load("left.png")]
walkup = [image.load("up.png"),image.load("up.png"),image.load("up.png"),image.load("up.png"),image.load("up.png"),image.load("up.png")]
walkdown = [image.load("down.png"),image.load("down.png"),image.load("down.png"),image.load("down.png"),image.load("down.png"),image.load("down.png")]
idle = [image.load("stand.png")]
global lost
lost = 0
class Main_ch(sprite.Sprite):
    def __init__(self, x, y, speed, i):
        super().__init__()
        self.image = transform.scale(image.load(i),(100, 100))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed
        self.left = False
        self.right = False
        self.up = False
        self.down= False
        self.idle = False
        self.count = 0
    def reset(self):
        virtual_surface.blit(self.image,(self.rect.x,self.rect.y))
    def hide(self):
        self.rect.x += 100000
    def show(self):
        self.rect.x -= 100000
class Main_charcter(sprite.Sprite):
    def __init__(self, x, y, speed, i):
        super().__init__()
        self.image = transform.scale(image.load(i),(150, 150))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed
        self.left = False
        self.right = False
        self.up = False
        self.down= False
        self.idle = False
        self.count = 0
    def reset(self):
        virtual_surface.blit(self.image,(self.rect.x,self.rect.y))
    def hide(self):
        self.rect.x += 100000
    def show(self):
        self.rect.x -= 100000
class Main_charcter1(sprite.Sprite):
    def __init__(self, x, y, speed, i):
        super().__init__()
        self.image = transform.scale(image.load(i),(450, 450))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed
        self.left = False
        self.right = False
        self.up = False
        self.down= False
        self.idle = False
        self.count = 0
    def reset(self):
        virtual_surface.blit(self.image,(self.rect.x,self.rect.y))
    def hide(self):
        self.rect.x += 100000
    def show(self):
        self.rect.x -= 100000
class Heart():
    def __init__(self, x, y, speed, i):
        super().__init__()
        self.image = transform.scale(image.load(i),(100, 100))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed
        self.left = False
        self.right = False
        self.up = False
        self.down= False
        self.idle = False
        self.count = 0
    def reset(self):
        virtual_surface.blit(self.image,(self.rect.x,self.rect.y))
    def hide(self):
        self.rect.x += 100000
    def show(self):
        self.rect.x -= 100000

class Slime(Main_charcter):
    def update(self):
        keys = key.get_pressed()
        if keys[K_a] or keys[K_LEFT] and self.rect.x > 10:
            global speed
            self.rect.x -= self.speed
            self.left = True
            self.right = False
            self.down = False
            self.up = False
            up = False
            down = False
            left = True
            right = False
            self.idle = False
            start = 10000
        elif keys[K_d] or keys[K_RIGHT] and self.rect.x < 1600:
            global speed
            self.rect.x += self.speed
            self.left = False
            self.right = True
            self.down = False
            self.up = False
            up = False
            down = False
            left = False
            right = True
            self.idle = False
            start = 10000
        elif keys[K_w] or keys[K_UP] and self.rect.y < 1000:
            self.rect.y -= self.speed
            self.left = False
            self.right = False
            self.down = False
            self.up = True
            up = True
            down = False
            left = False
            right = False
            self.idle = False
            start = 10000
        elif keys[K_s] or keys[K_DOWN] and self.rect.y > -1000 or self.rect.y > 500:
            self.rect.y += self.speed
            self.left = False
            self.right = False
            self.down = True
            self.up = False
            up = False
            down = True
            left = False
            right = False
            self.idle = False
            start = 10000
            if self.rect.y > 900:
                    global lost
                    lost += 1
                    self.rect.x = 100
                    self.rect.y = 100
                    death.play()
        elif idle:
            self.idle = True
            self.left = False
            self.right = False
            self.down = False
            self.up = False
            self.count = 0
            self.up = False
            up = False
            down = False
            left = False
            right = False
            self.idle = False
    def animation(self):
        if self.count + 1 >= 30:
            self.count = 0
        if self.left == True:
            virtual_surface.blit(walkleft[self.count//10],(self.rect.x, self.rect.y))
            self.count += 1
        elif self.right == True:
            virtual_surface.blit(walkright[self.count//10],(self.rect.x, self.rect.y))
            self.count += 1
        elif self.up == True:
            virtual_surface.blit(walkup[self.count//10],(self.rect.x, self.rect.y))
            self.count += 1
        elif self.down == True:
            virtual_surface.blit(walkdown[self.count//10],(self.rect.x, self.rect.y))
            self.count += 1
        else:
            virtual_surface.blit(idle[self.count//10],(self.rect.x, self.rect.y))          
    def start1(self):
        self.rect.y = 100
        self.rect.x = 300
class Rabbit(Main_ch): 
    def update(self):
        rand = randint(1,25)
        rand4 = randint(1,25)
        rand1 = randint(1,2)
        if rand1 == 1:
            for i in range(rand):
                self.rect.x += 2
                self.rect.x -= 1
            for i in range(rand4):
                self.rect.y -= 2
                self.rect.y += 1
            if self.rect.y > 550:
               self.rect.y -= 20
            elif self.rect.y > 600:
                self.rect.y += 500
            elif self.rect.x > 1600:
                self.rect.x -= 20
            elif self.rect.x > 1800:
                self.rect.x -= 500
            elif self.rect.y > 1600:
               self.rect.y += 20
            elif self.rect.y > 850:
               self.rect.y += 500
            elif self.rect.x > 10:
                self.rect.x += 20
            elif self.rect.x > 60:
                self.rect.x += 50
        if rand1 == 2:
            for i in range(rand):
                self.rect.x -= 2
                self.rect.x += 1
            for i in range(rand4):
                self.rect.y += 2
                self.rect.y -= 1
            self.rect.y += rand4
            self.right = False
            self.left = True
            if self.rect.y > 550:
               self.rect.y -= 20
            elif self.rect.y > 600:
                self.rect.y += 500
            elif self.rect.x > 1600:
                self.rect.x -= 20
            elif self.rect.x > 1800:
                self.rect.x -= 500
            elif self.rect.y > 1600:
               self.rect.y += 20
            elif self.rect.y > 850:
               self.rect.y += 500
            elif self.rect.x > 10:
                self.rect.x += 20
            elif self.rect.x > 60:
                self.rect.x += 50
Quest1_1 = 0
Quest1 = 0
Quest_comp = False
class Duck(Main_charcter):
    def update(self):
        if sprite.collide_rect(self, mainch):
            Quest1_1 =+ 1
            col = True
        if sprite.collide_rect(self, mainch) and Quest1_1 == 1 and Quest_comp == False:
            quack.play()
class Quest(Main_charcter):
    def startxy(self):
        self.rect.x = -100
        self.rect.y = 100
    def update(self):
        if Quest1 == 1:
            for i in range(100):
                self.rect.x -= 1
                self.rect.x += 2
            Quest1 -= 1





            
            
        
modes = [(1920, 1080), (1768, 992), (1680, 1050), (1600, 1200), (1600, 1024), (1600, 900
), (1440, 900), (1400, 1050), (1360, 768), (1280, 1024), (1280, 960), (1280, 800
), (1280, 768), (1280, 720), (1152, 864), (1024, 768), (800, 600), (720, 576), (
720, 480), (640, 480)]       
col = False
quest_frame = Quest(-100, 100, 1, "quest.png")
duck = Duck(500, 400, 0, "duck.png")
rock = Main_charcter(1200, 200, 0, "rock.png")
rock2 = Main_charcter(700, 400, 0, "rock.png")
bush = Main_charcter(500, 200, 0, "bush.png")
bush2 = Main_charcter(1000, 250, 0, "bush.png")
bush3 = Main_charcter(700, 30, 0, "bush.png")
bush4= Main_charcter(900, 400, 0, "bush.png")
bush1_1 = Main_charcter(500, 200, 0, "bush.png")
bush2_2 = Main_charcter(1000, 250, 0, "bush.png")
bush3_3 = Main_charcter(700, 30, 0, "bush.png")
bush4_4 = Main_charcter(900, 400, 0, "bush.png")
tree1 = Main_charcter1(60, 100, 0, "tree.png")
mainch = Slime(100, 100, 8, "stand.png")
rabbit = Rabbit(700, 300, 1, "rabbit.png")
rabbit2 = Rabbit(700, 200, 1, "rabbit.png")
rabbit3 = Rabbit(700, 500, 1, "rabbit.png")
rabbit4 = Rabbit(700, 200, 1, "rabbit.png")
bg2 = transform.scale(image.load("floor.jpg"), (w, h))
heart1 = Heart(40, 10, 0, "heart.png")
heart2 = Heart(90, 10, 0, "heart.png")
heart3 = Heart(140, 10, 0, "heart.png")
bg3 = transform.scale(image.load("floor2.jpg"), (w, h))
font.init()
font = font.Font("Days2.ttf", 20)
randopis1 = randint(1, 700)
randopis2 = randint(1, 500)
randopis3 = randint(1, 700)
randopis4 = randint(1, 500)
randopis5 = randint(1, 700)
randopis6 = randint(1, 500)
randopis7 = randint(1, 700)
randopis8 = randint(1, 500)
game = True
final = False
bgx = 0
lose = False
while game:
    for e in event.get():
        if e.type == QUIT:
            game = False
        if e.type == VIDEORESIZE:
            current_size = e.size
        if e.type == KEYDOWN:
            if e.key == K_F11:
                is_fullscreen = not is_fullscreen
                if is_fullscreen:
                    last_size = current_size
                    current_size = fullscreen_size
                    screen = display.set_mode(current_size, FULLSCREEN)
                else:
                    current_size = last_size
                    screen = display.set_mode(current_size, RESIZABLE)
                    screen = display.set_mode(current_size, RESIZABLE)
            if e.key == K_LALT and e.key == K_F4:
                game = False
            if e.key == K_f:
                fpscons = int(input("Вкажіть фпс:"))
                if fpscons >= 600:
                    Fps = 60
                    print("Дуже великий фпс, будь ласка спробуйте меньше, а зараз встановлено", Fps,"Кадрів за секунду")
                if fpscons <= 600 and fpscons != 0:
                    Fps = fpscons
                    print("Встановлено", Fps,"кадрів за секунду")
                if fpscons == 0:
                    print("Встановлено необмежена кількість кадрів за секунду")
                    Fps = fpscons
            if e.key == K_r:
                start = 10
                ava = []
                for i in range(100):
                    start -= 1
                    ava.append(int(clock.get_fps()))
                if start <= 0:
                    l = sorted(ava)[len(ava) // 2]
                    print("Середній фпс:", l)
                    start = 100
            if e.key == K_t:
               ava = []
               for i in range(100):
                    start -= 1
                    ava.append(int(clock.get_fps()))
                    if start <= 0:
                        l = min(ava)
                        print("Найменьший фпс:", l)
                        start = 100
            if e.key == K_y:
               ava = []
               for i in range(100):
                    start -= 1
                    ava.append(int(clock.get_fps()))
                    if start <= 0:
                        l = max(ava)
                        print("Максимальний фпс:", l)
                        start = 100
            if e.key == K_k:
                rabbit.hide()
                rabbit2.hide()
                rabbit3.hide()
                rabbit4.hide()
                print("Всіх ентеті було прибрано")
            if e.key == K_l:
                rabbit.show()
                rabbit2.show()
                rabbit3.show()
                rabbit4.show()
                print("Всіх ентеті знову було добавлено")
            if e.key == K_g:
                mousepos = mouse.get_pos()
                rabbit.rect.x, rabbit.rect.y = mousepos
                rabbit2.rect.x, rabbit2.rect.y = mousepos
                rabbit3.rect.x, rabbit3.rect.y = mousepos
                rabbit4.rect.x, rabbit4.rect.y = mousepos
            if e.key == K_F1:
                print("Привіт!Це консоль розробника ось, що робить кожна з клавіш:\n F - можете ввести свою частоту кадрів за секунду(до 800) \n K - Вбирає всіх ентіті(сутностей) \n L - повертає всіх ентіті(сутностей) \n R - показує середню кількість кадрів \n T - показує найменьшу кількість кадрів \n Y - показує найбульшу кількість кадрів \n G - переносить кроликів в позицію миші \n Дякую за увагу, вдачі тобі тестер ")
                
    if final != True:
        fps = clock.get_fps()
        text = font.render("Fps:"+str(int(fps)),  True, (0, 0, 0))
        

        virtual_surface.blit(bg3, (0, 0))
        virtual_surface.blit(text, (1500, 10))
        if mainch.rect.x > 1605:
            virtual_surface.blit(bg3,(0, 0))
            mainch.rect.x = 50
            duck.show()
            duck.update()
            duck.reset()
            tree1.hide()
            rock.hide()
            rock2.hide()
            bush.hide()
            bush2.hide()
            bush3.hide()
            bush4.hide()
            bush1_1.show()
            bush2_2.show()
            bush3_3.show()
            bush4_4.show()
            bush1_1.update()
            bush1_1.reset()
            bush2_2.update()
            bush2_2.reset()
            bush3_3.update()
            bush3_3.reset()
            bush4_4.update()
            bush4_4.reset()
            bush1_1.rect.x = randopis1
            bush1_1.rect.y = randopis2
            bush2_2.rect.x = randopis3
            bush2_2.rect.y = randopis4
            bush3_3.rect.x = randopis5
            bush3_3.rect.y = randopis6
            bush4_4.rect.x = randopis7
            bush4_4.rect.y = randopis8
            
            
            mainch.reset()

            rabbit.hide()
            rabbit2.hide()
            rabbit3.hide()
            rabbit4.hide()
            mainch.update()
            mainch.animation()
            if col == True:
                quest_frame.update()
                quest_frame.reset()
        elif mainch.rect.x < 10:
            virtual_surface.blit(bg2, (0, 0))
            mainch.rect.x = 1590
            bush1_1.hide()
            bush2_2.hide()
            bush3_3.hide()
            bush4_4.hide()
            bush1_1.rect.x = randopis1
            bush1_1.rect.y = randopis2
            bush2_2.rect.x = randopis3
            bush2_2.rect.y = randopis4
            bush3_3.rect.x = randopis5
            bush3_3.rect.y = randopis6
            bush4_4.rect.x = randopis7
            bush4_4.rect.y = randopis8
            bush1_1.update()
            bush1_1.reset()
            bush2_2.update()
            bush2_2.reset()
            bush3_3.update()
            bush3_3.reset()
            bush4_4.update()
            bush4_4.reset()
            duck.hide()
            tree1.show()
            tree1.update()
            mainch.reset()
            rock.show()
            rock.update()
            rock2.show()
            rock2.update()
            bush.show()
            bush.update()
            bush.reset()
            bush2.show()
            bush2.update()
            bush2.reset()
            bush3.show()
            bush3.update()
            bush3.reset()
            bush4.show()
            bush4.update()
            bush4.reset()
            rabbit.show()
            rabbit2.show()
            rabbit3.show()
            rabbit4.show()
            mainch.update()
            mainch.animation()
            if col == True:
                quest_frame.update()
                quest_frame.reset()
        duck.hide()
        bush1_1.update()
        bush1_1.reset()
        bush2_2.update()
        bush2_2.reset()
        bush3_3.update()
        bush3_3.reset()
        bush4_4.update()
        bush4_4.reset()
        bush1_1.hide()
        bush2_2.hide()
        bush3_3.hide()
        bush4_4.hide()
        tree1.update()
        rabbit.reset()
        rabbit2.reset()
        rabbit3.reset()
        rabbit4.reset()
        bush.update()
        bush.reset()
        bush2.update()
        bush2.reset()
        bush3.update()
        bush3.reset()
        bush4.update()
        bush4.reset()
        mainch.reset()
        mainch.update()
        mainch.animation()
        rock.update()
        rock.reset()
        rock2.update()
        rock2.reset()
        tree1.reset()
        
        heart1.reset()
        heart2.reset()
        heart3.reset()
        if col == True:
                quest_frame.update()
                quest_frame.reset()
        rand3 = randint(1, 50)
        if rand3 == 50:
            rabbit.update()
        if rand3 == 28:
            rabbit2.update()
        if rand3 == 22:
            rabbit3.update()
        if rand3 == 10:
            rabbit4.update()
        if lost == 1:
            heart3.hide()
        if lost == 2:
            heart2.hide()
        if lost == 3:
            heart1.hide()
            final = True
            lose = True
            mixer.music.stop()
    if final == True:
        loose.play(True)
        loose.set_volume(0.1)
        virtual_surface.blit(loose_bg, (bgx +0, 0))
        virtual_surface.blit(loose_bg, (bgx +1050, 0))
        bgx -= 2
        if bgx == -1050:
            bgx = 0
        
    
    scaled_surface = transform.scale(virtual_surface, current_size)
    window.blit(scaled_surface,(0, 0))
    display.update()
    clock.tick(Fps)